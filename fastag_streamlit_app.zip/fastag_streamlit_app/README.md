# FASTag Fraud Detection App

## Run locally
pip install -r requirements.txt
streamlit run app.py
